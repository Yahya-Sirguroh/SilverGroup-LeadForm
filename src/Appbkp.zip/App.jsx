import React, { useState, useEffect } from 'react';
import { Loader2, CheckCircle, Phone, User, Building } from 'lucide-react';

const LeadForm = () => {
  // Load Google Fonts
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    return () => document.head.removeChild(link);
  }, []);

  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Personal Details
    fullName: '',
    email: '',
    mobileNumber: '',
    address: '',
    locality: '',
    city: '',
    country: '',
    pinCode: '',
    visitingFor: 'Self',
    
    // Professional Details
    occupation: '',
    organization: '',
    industry: '',
    designation: '',
    officeLocation: '',
    officePinCode: '',
    
    // Essentials
    purposeOfPurchase: 'Personal Use',
    propertyType: '3 BHK',
    currentResidentType: 'Own Residence',
    budgetRange: '1Cr - 1.25Cr',
    budgetRangeHigher: '',
    willBuyIn: '',
    
    // How did you hear
    hearAboutUs: [],
    referenceDetails: '',
    channelPartnerCompany: '',
    channelPartnerName: '',
    channelPartnerMobile: '',
    channelPartnerRERA: '',
    channelPartnerEmail: ''
  });
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Rotate background images every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % 6);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  // Styling Constants
  const glassStyle = "bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg border border-white border-opacity-20 rounded-2xl shadow-2xl";
  const inputStyle = "w-full bg-black bg-opacity-20 border border-white border-opacity-10 rounded-lg px-3 py-2.5 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition-all text-sm";
  const labelStyle = "text-gray-300 text-xs mb-1.5 block font-light tracking-wide";

  const validateField = (name, value) => {
    switch (name) {
      case 'fullName':
        return !value || value.trim().length < 2 ? 'Name must be at least 2 characters' : '';
      case 'email':
        return !value || !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value) ? 'Invalid email address' : '';
      case 'address':
        return !value || value.trim().length < 5 ? 'Address must be at least 5 characters' : '';
      case 'city':
        return !value || value.trim().length < 2 ? 'City is required' : '';
      case 'pinCode':
      case 'officePinCode':
        return value && !/^\d{6}$/.test(value) ? 'Enter valid 6-digit PIN code' : '';
      case 'mobileNumber':
      case 'channelPartnerMobile':
        return !value || !/^[6-9]\d{9}$/.test(value) ? 'Enter valid 10-digit mobile number' : '';
      default:
        return '';
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (type === 'checkbox') {
      setFormData(prev => {
        const currentArray = prev[name] || [];
        if (checked) {
          return { ...prev, [name]: [...currentArray, value] };
        } else {
          return { ...prev, [name]: currentArray.filter(item => item !== value) };
        }
      });
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors(prev => ({ ...prev, [name]: error }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched(prev => ({ ...prev, [name]: true }));
    const error = validateField(name, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const validateForm = () => {
    const newErrors = {};
    Object.keys(formData).forEach(key => {
      const error = validateField(key, formData[key]);
      if (error) newErrors[key] = error;
    });
    setErrors(newErrors);
    setTouched({
      fullName: true,
      email: true,
      address: true,
      city: true,
      pinCode: true,
      mobileNumber: true,
      occupation: true,
      area: true
    });
    return Object.keys(newErrors).length === 0;
  };

  const sendOTP = async (phoneNumber) => {
    console.log('Sending OTP to:', phoneNumber);
    await new Promise(resolve => setTimeout(resolve, 1500));
    return { success: true, verificationId: 'demo_' + Date.now() };
  };

  const handleInitialSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      setError('Please fix the errors above');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const phoneNumber = "+91" + formData.mobileNumber;
      const result = await sendOTP(phoneNumber);
      
      if (result.success) {
        setStep(2);
      } else {
        throw new Error('Failed to send OTP');
      }
    } catch (err) {
      console.error("SMS Error:", err);
      setError(err.message || "Failed to send OTP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const verifyOtpAndSubmit = async () => {
    if (otp.length !== 6) {
      setError('Please enter 6-digit OTP');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (otp === '123456' || true) {
        await submitToFarvision(formData);
        setStep(3);
      } else {
        throw new Error('Invalid OTP');
      }
    } catch (err) {
      console.error("OTP Error:", err);
      setError('Invalid OTP. Please check and try again.');
    } finally {
      setLoading(false);
    }
  };

  const submitToFarvision = async (data) => {
    const payload = {
      lead: {
        name: data.fullName,
        email: data.email,
        address: data.address,
        city: data.city,
        pin_code: data.pinCode,
        mobile: data.mobileNumber,
        occupation: data.occupation,
        property_type: data.propertyType,
        area: data.area || null,
        segment: data.segment,
        parkings: data.parkings || 0,
        source: 'Website Form',
        status: 'New',
        created_at: new Date().toISOString()
      }
    };

    console.log("Pushing to Farvision SFA...", payload);
    
    try {
      const response = await fetch('YOUR_FARVISION_API_ENDPOINT', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) throw new Error('Failed to submit');
      return await response.json();
    } catch (err) {
      console.log('API call would happen here');
      return new Promise(resolve => setTimeout(resolve, 1000));
    }
  };

  const resendOTP = async () => {
    setOtp('');
    setError('');
    setLoading(true);
    
    try {
      const phoneNumber = "+91" + formData.mobileNumber;
      await sendOTP(phoneNumber);
      setError('');
      const successMsg = document.createElement('div');
      successMsg.textContent = 'OTP sent successfully!';
      successMsg.className = 'text-green-400 text-sm mt-2';
      document.querySelector('.otp-section')?.appendChild(successMsg);
      setTimeout(() => successMsg.remove(), 3000);
    } catch (err) {
      setError('Failed to resend OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const backgroundImages = [
    'https://i.postimg.cc/43xNZYWp/image2.jpg',
    'https://i.postimg.cc/8cZgN0Nn/image3.jpg',
    'https://i.postimg.cc/CxJSzbff/image6.jpg',
    'https://i.postimg.cc/xT6Vfg6F/image1.jpg',
    'https://i.postimg.cc/VNJLsGFG/image4.jpg',
    'https://i.postimg.cc/yYqrfQJ2/image5.jpg'
  ];

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 md:p-6 overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Dark Grey Background with Grid Overlay */}
      <div className="absolute inset-0 z-0">
        {/* Solid Dark Grey Background */}
        <div className="absolute inset-0 bg-gray-800" />
        
        {/* Grid Lines Overlay */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(255, 255, 255, 0.1) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(255, 255, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className={`${glassStyle} w-full max-w-4xl p-6 md:p-12 transition-all duration-500 relative z-10`}>
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="h-16 w-16 mx-auto mb-4 bg-gradient-to-br from-gray-300 to-gray-500 rounded-full flex items-center justify-center">
            {/* <Building className="w-8 h-8 text-gray-900" /> */}
            <img src="SilverGroupLogow_oBG.png" alt="SilverHouse Logo" />
          </div>
          <h1 className="text-3xl md:text-4xl font-light text-white tracking-widest uppercase" style={{ fontFamily: "'Playfair Display', serif" }}>Silver Group</h1>
          <p className="text-gray-300 mt-2 italic font-light">Lead Form</p>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-8">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                step >= s ? 'bg-gray-300 text-gray-900' : 'bg-gray-700 text-gray-400'
              } font-semibold transition-all`}>
                {s}
              </div>
              {s < 3 && <div className={`w-16 h-1 ${step > s ? 'bg-gray-300' : 'bg-gray-700'} transition-all`} />}
            </div>
          ))}
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-500 bg-opacity-20 border border-red-500 border-opacity-50 rounded-lg text-red-200">
            {error}
          </div>
        )}

        {/* Step 1: Main Form */}
        {step === 1 && (
          <div className="space-y-6">
            {/* Personal Details */}
            <div>
              <h3 className="text-white text-lg font-light mb-4 uppercase tracking-wider border-b border-gray-600 pb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                1. Personal Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className={labelStyle}>Full Name <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter your full name"
                    className={inputStyle}
                  />
                  {errors.fullName && touched.fullName && (
                    <p className="text-red-400 text-xs mt-1">{errors.fullName}</p>
                  )}
                </div>
                
                <div>
                  <label className={labelStyle}>Mobile Number <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    name="mobileNumber"
                    value={formData.mobileNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter mobile number"
                    className={inputStyle}
                    maxLength="10"
                  />
                  {errors.mobileNumber && touched.mobileNumber && (
                    <p className="text-red-400 text-xs mt-1">{errors.mobileNumber}</p>
                  )}
                </div>

                <div>
                  <label className={labelStyle}>Email ID <span className="text-red-400">*</span></label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter email address"
                    className={inputStyle}
                  />
                  {errors.email && touched.email && (
                    <p className="text-red-400 text-xs mt-1">{errors.email}</p>
                  )}
                </div>

                <div className="md:col-span-2">
                  <label className={labelStyle}>Residential Address <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter your address"
                    className={inputStyle}
                  />
                  {errors.address && touched.address && (
                    <p className="text-red-400 text-xs mt-1">{errors.address}</p>
                  )}
                </div>

                <div>
                  <label className={labelStyle}>Locality</label>
                  <input
                    type="text"
                    name="locality"
                    value={formData.locality}
                    onChange={handleInputChange}
                    placeholder="Enter locality"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>City <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter city"
                    className={inputStyle}
                  />
                  {errors.city && touched.city && (
                    <p className="text-red-400 text-xs mt-1">{errors.city}</p>
                  )}
                </div>

                <div>
                  <label className={labelStyle}>Country</label>
                  <input
                    type="text"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                    placeholder="Enter country"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>PIN Code <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    name="pinCode"
                    value={formData.pinCode}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter PIN code"
                    className={inputStyle}
                    maxLength="6"
                  />
                  {errors.pinCode && touched.pinCode && (
                    <p className="text-red-400 text-xs mt-1">{errors.pinCode}</p>
                  )}
                </div>

                <div>
                  <label className={labelStyle}>Visiting / Meeting on behalf of</label>
                  <select
                    name="visitingFor"
                    value={formData.visitingFor}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="Self">Self</option>
                    <option value="Family">Family</option>
                    <option value="Friend / Colleague">Friend / Colleague</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Professional Details */}
            <div>
              <h3 className="text-white text-lg font-light mb-4 uppercase tracking-wider border-b border-gray-600 pb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                2. Professional Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className={labelStyle}>Occupation</label>
                  <select
                    name="occupation"
                    value={formData.occupation}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="">Select occupation</option>
                    <option value="Salaried">Salaried</option>
                    <option value="Self Employed">Self Employed</option>
                    <option value="Professional">Professional</option>
                    <option value="Retired">Retired</option>
                  </select>
                </div>

                <div>
                  <label className={labelStyle}>Organization</label>
                  <input
                    type="text"
                    name="organization"
                    value={formData.organization}
                    onChange={handleInputChange}
                    placeholder="Enter organization name"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>Industry</label>
                  <input
                    type="text"
                    name="industry"
                    value={formData.industry}
                    onChange={handleInputChange}
                    placeholder="Enter industry"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>Designation</label>
                  <input
                    type="text"
                    name="designation"
                    value={formData.designation}
                    onChange={handleInputChange}
                    placeholder="Enter designation"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>Office Location</label>
                  <input
                    type="text"
                    name="officeLocation"
                    value={formData.officeLocation}
                    onChange={handleInputChange}
                    placeholder="Enter office location"
                    className={inputStyle}
                  />
                </div>

                <div>
                  <label className={labelStyle}>Office PIN Code</label>
                  <input
                    type="text"
                    name="officePinCode"
                    value={formData.officePinCode}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter PIN code"
                    className={inputStyle}
                    maxLength="6"
                  />
                  {errors.officePinCode && touched.officePinCode && (
                    <p className="text-red-400 text-xs mt-1">{errors.officePinCode}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Essentials */}
            <div>
              <h3 className="text-white text-lg font-light mb-4 uppercase tracking-wider border-b border-gray-600 pb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                3. Essentials
              </h3>
              <div className="space-y-4">
                <div>
                  <label className={labelStyle}>Purpose of Purchase</label>
                  <select
                    name="purposeOfPurchase"
                    value={formData.purposeOfPurchase}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="Personal Use">Personal Use</option>
                    <option value="Investment">Investment</option>
                    <option value="Second Home">Second Home</option>
                  </select>
                </div>

                <div>
                  <label className={labelStyle}>Residential Configuration</label>
                  <select
                    name="propertyType"
                    value={formData.propertyType}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="1 BHK">1 BHK</option>
                    <option value="2 BHK">2 BHK</option>
                    <option value="3 BHK (1 +1 JODI)">3 BHK (1 +1 JODI)</option>
                    <option value="4 BHK (2+2 JODI)">4 BHK (2+2 JODI)</option>
                  </select>
                </div>

                <div>
                  <label className={labelStyle}>Current Resident Type</label>
                  <select
                    name="currentResidentType"
                    value={formData.currentResidentType}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="Own Residence">Own Residence</option>
                    <option value="Company Provide">Company Provide</option>
                    <option value="Rented">Rented</option>
                  </select>
                </div>

                <div>
                  <label className={labelStyle}>Budget Range (Rs.)</label>
                  <select
                    name="budgetRange"
                    value={formData.budgetRange}
                    onChange={handleInputChange}
                    className={inputStyle}
                  >
                    <option value="1Cr - 1.25Cr">1Cr - 1.25Cr</option>
                    <option value="1.26Cr - 1.50 Cr">1.26Cr - 1.50 Cr</option>
                    <option value="1.51Cr - 1.75Cr">1.51Cr - 1.75Cr</option>
                    <option value="1.76Cr - 2Cr">1.76Cr - 2Cr</option>
                    <option value="2.01Cr - 2.25Cr">2.01Cr - 2.25Cr</option>
                    <option value="2.26Cr Onwards">2.26Cr Onwards</option>
                  </select>
                </div>

                <div>
                  <label className={labelStyle}>Will Buy in (Period)</label>
                  <input
                    type="text"
                    name="willBuyIn"
                    value={formData.willBuyIn}
                    onChange={handleInputChange}
                    placeholder="e.g., 3 months, 6 months"
                    className={inputStyle}
                  />
                </div>
              </div>
            </div>

            {/* How Did You Hear About Us */}
            <div>
              <h3 className="text-white text-lg font-light mb-4 uppercase tracking-wider border-b border-gray-600 pb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                4. How Did You Hear About Us
              </h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {['Website', 'Online Portal', 'Newspaper', 'Hoarding', 'Email / SMS', 'Direct Walk in', 'Event Exhibition', 'Channel Partner'].map(option => (
                    <label key={option} className="flex items-center gap-2 text-gray-300 cursor-pointer">
                      <input
                        type="checkbox"
                        name="hearAboutUs"
                        value={option}
                        checked={formData.hearAboutUs?.includes(option)}
                        onChange={handleInputChange}
                        className="w-4 h-4"
                      />
                      <span className="text-sm">{option}</span>
                    </label>
                  ))}
                </div>

                <div>
                  <label className={labelStyle}>Reference / Others</label>
                  <input
                    type="text"
                    name="referenceDetails"
                    value={formData.referenceDetails}
                    onChange={handleInputChange}
                    placeholder="Enter reference details or other sources"
                    className={inputStyle}
                  />
                </div>
              </div>
            </div>

            {/* Channel Partner Details */}
            {formData.hearAboutUs?.includes('Channel Partner') && (
              <div>
                <h3 className="text-white text-lg font-light mb-4 uppercase tracking-wider border-b border-gray-600 pb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                  5. Channel Partner Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelStyle}>Company Name</label>
                    <input
                      type="text"
                      name="channelPartnerCompany"
                      value={formData.channelPartnerCompany}
                      onChange={handleInputChange}
                      placeholder="Enter company name"
                      className={inputStyle}
                    />
                  </div>

                  <div>
                    <label className={labelStyle}>CP Name</label>
                    <input
                      type="text"
                      name="channelPartnerName"
                      value={formData.channelPartnerName}
                      onChange={handleInputChange}
                      placeholder="Enter CP name"
                      className={inputStyle}
                    />
                  </div>

                  <div>
                    <label className={labelStyle}>Mobile No.</label>
                    <input
                      type="text"
                      name="channelPartnerMobile"
                      value={formData.channelPartnerMobile}
                      onChange={handleInputChange}
                      onBlur={handleBlur}
                      placeholder="Enter mobile number"
                      className={inputStyle}
                      maxLength="10"
                    />
                    {errors.channelPartnerMobile && touched.channelPartnerMobile && (
                      <p className="text-red-400 text-xs mt-1">{errors.channelPartnerMobile}</p>
                    )}
                  </div>

                  <div>
                    <label className={labelStyle}>RERA No.</label>
                    <input
                      type="text"
                      name="channelPartnerRERA"
                      value={formData.channelPartnerRERA}
                      onChange={handleInputChange}
                      placeholder="Enter RERA number"
                      className={inputStyle}
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className={labelStyle}>Email Id.</label>
                    <input
                      type="email"
                      name="channelPartnerEmail"
                      value={formData.channelPartnerEmail}
                      onChange={handleInputChange}
                      placeholder="Enter email address"
                      className={inputStyle}
                    />
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={handleInitialSubmit}
              disabled={loading}
              className="w-full md:w-auto md:mx-auto md:block mt-6 bg-gradient-to-r from-gray-200 to-gray-400 text-black font-bold py-3 px-12 rounded-full hover:scale-105 active:scale-95 transition-transform duration-200 shadow-xl uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Sending OTP...
                </>
              ) : (
                'Submit & Verify'
              )}
            </button>
            
            <p className="text-gray-400 text-xs text-center mt-3">
              Demo Mode: Any 6-digit OTP will work (try 123456)
            </p>
          </div>
        )}

        {/* Step 2: OTP Verification */}
        {step === 2 && (
          <div className="max-w-md mx-auto text-center otp-section">
            <div className="mb-6">
              <div className="w-20 h-20 mx-auto mb-4 bg-gray-700 rounded-full flex items-center justify-center">
                <Phone className="w-10 h-10 text-gray-300" />
              </div>
              <h2 className="text-2xl text-white mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>Verify Your Number</h2>
              <p className="text-gray-400">
                We've sent a 6-digit code to<br />
                <span className="text-white font-semibold">+91 {formData.mobileNumber}</span>
              </p>
            </div>

            <div className="mb-6">
              <label className={labelStyle}>Enter OTP</label>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                className={`${inputStyle} text-center text-2xl tracking-widest`}
                maxLength="6"
                autoFocus
              />
            </div>

            <button
              onClick={verifyOtpAndSubmit}
              disabled={loading || otp.length !== 6}
              className="w-full bg-gradient-to-r from-gray-200 to-gray-400 text-black font-bold py-4 rounded-full hover:scale-105 active:scale-95 transition-transform duration-200 shadow-xl uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify & Submit'
              )}
            </button>

            <button
              onClick={resendOTP}
              disabled={loading}
              className="mt-4 text-gray-400 hover:text-white transition-colors text-sm underline"
            >
              Didn't receive code? Resend OTP
            </button>
            
            <p className="text-gray-500 text-xs mt-4">Demo: Use 123456 as OTP</p>
          </div>
        )}

        {/* Step 3: Success */}
        {step === 3 && (
          <div className="max-w-md mx-auto text-center">
            <div className="mb-6">
              <div className="w-24 h-24 mx-auto mb-4 bg-green-500 bg-opacity-20 rounded-full flex items-center justify-center">
                <CheckCircle className="w-16 h-16 text-green-400" />
              </div>
              <h2 className="text-3xl text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Thank You!</h2>
              <p className="text-gray-300 text-lg leading-relaxed">
                Your inquiry has been successfully submitted.<br />
                Our team will contact you shortly.
              </p>
            </div>

            <div className="bg-black bg-opacity-30 rounded-xl p-6 mb-6 text-left">
              <h3 className="text-gray-400 text-sm uppercase tracking-wide mb-3">Your Details</h3>
              <div className="space-y-2 text-white">
                <p><span className="text-gray-400">Name:</span> {formData.fullName}</p>
                <p><span className="text-gray-400">Email:</span> {formData.email}</p>
                <p><span className="text-gray-400">Mobile:</span> +91 {formData.mobileNumber}</p>
                <p><span className="text-gray-400">Address:</span> {formData.address}, {formData.city} - {formData.pinCode}</p>
                <p><span className="text-gray-400">Property:</span> {formData.propertyType}</p>
                <p><span className="text-gray-400">Budget:</span> {formData.budgetRange}</p>
              </div>
            </div>

            <button
              onClick={() => {
                setStep(1);
                setFormData({
                  fullName: '',
                  email: '',
                  mobileNumber: '',
                  address: '',
                  locality: '',
                  city: '',
                  country: '',
                  pinCode: '',
                  visitingFor: 'Self',
                  occupation: '',
                  organization: '',
                  industry: '',
                  designation: '',
                  officeLocation: '',
                  officePinCode: '',
                  purposeOfPurchase: 'Personal Use',
                  propertyType: '3 BHK',
                  currentResidentType: 'Own Residence',
                  budgetRange: '1Cr - 1.25Cr',
                  budgetRangeHigher: '',
                  willBuyIn: '',
                  hearAboutUs: [],
                  referenceDetails: '',
                  channelPartnerCompany: '',
                  channelPartnerName: '',
                  channelPartnerMobile: '',
                  channelPartnerRERA: '',
                  channelPartnerEmail: ''
                });
                setOtp('');
                setError('');
                setErrors({});
                setTouched({});
              }}
              className="w-full bg-gradient-to-r from-gray-600 to-gray-700 text-white font-bold py-3 rounded-full hover:scale-105 transition-transform duration-200"
            >
              Submit Another Inquiry
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeadForm;